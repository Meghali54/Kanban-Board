import React from 'react';
import { render, screen } from '@testing-library/react';
import TaskCard from '../components/TaskCard';

describe('TaskCard Component', () => {
  test('renders task title', () => {
    const task = { title: 'Test Task', description: 'Test Description' };
    render(<TaskCard task={task} />);
    expect(screen.getByText('Test Task')).toBeInTheDocument();
  });
});