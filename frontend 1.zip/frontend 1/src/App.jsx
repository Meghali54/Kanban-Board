import React from 'react';
import KanbanBoard from './components/KanbanBoard';
import { TaskProvider } from './context/TaskContext';

const App = () => {
  return (
    <TaskProvider>
      <div className="app">
        <h1>Real-Time Kanban Board</h1>
        <KanbanBoard />
      </div>
    </TaskProvider>
  );
};

export default App;
