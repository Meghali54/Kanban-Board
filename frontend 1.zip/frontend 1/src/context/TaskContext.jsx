
import { createContext, useContext, useState, useEffect } from 'react';
import { socket } from '../socket';

const TaskContext = createContext();

export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);

  // Listen for task updates from WebSocket
  useEffect(() => {
    socket.on('task-updated', (updatedTask) => {
      setTasks((prevTasks) => {
        const existingIndex = prevTasks.findIndex(t => t.id === updatedTask.id);
        if (existingIndex !== -1) {
          const updated = [...prevTasks];
          updated[existingIndex] = updatedTask;
          return updated;
        } else {
          return [...prevTasks, updatedTask];
        }
      });
    });

    return () => {
      socket.off('task-updated');
    };
  }, []);

  return (
    <TaskContext.Provider value={{ tasks, setTasks }}>
      {children}
    </TaskContext.Provider>
  );
};

export const useTasks = () => useContext(TaskContext);
