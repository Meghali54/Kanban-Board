// src/components/KanbanBoard.jsx
import React, { useState, useEffect } from 'react';
import { useTasks } from '../context/TaskContext';
import { socket } from '../socket';
import './KanbanBoard.css';

const STATUSES = ['Todo', 'In Progress', 'Done'];

const KanbanBoard = () => {
  const { tasks, setTasks } = useTasks();
  const [newTask, setNewTask] = useState('');

  useEffect(() => {
    socket.emit('load-tasks');

    socket.on('tasks', (loadedTasks) => {
      setTasks(loadedTasks);
    });

    socket.on('task-updated', (updatedTask) => {
      setTasks((prev) =>
        prev.map((task) =>
          task.id === updatedTask.id ? updatedTask : task
        )
      );
    });

    socket.on('task-deleted', (deletedId) => {
      setTasks((prev) => prev.filter((task) => task.id !== deletedId));
    });

    socket.on('task-added', (addedTask) => {
      setTasks((prev) => [...prev, addedTask]);
    });

    return () => {
      socket.off('tasks');
      socket.off('task-updated');
      socket.off('task-deleted');
      socket.off('task-added');
    };
  }, []);

  const onDragEnd = (result) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;

    const movedTask = tasks.find((t) => t.id === draggableId);
    const updatedTask = {
      ...movedTask,
      status: destination.droppableId,
    };

    const newTasks = tasks.map((task) =>
      task.id === updatedTask.id ? updatedTask : task
    );

    setTasks(newTasks);
    socket.emit('update-task', updatedTask);
  };

  const handleAddTask = () => {
    if (!newTask.trim()) return;
    const task = {
      id: Date.now().toString(),
      title: newTask,
      status: 'Todo',
    };
    setTasks((prev) => [...prev, task]);
    socket.emit('add-task', task);
    setNewTask('');
  };

  const handleDeleteTask = (id) => {
    setTasks((prev) => prev.filter((task) => task.id !== id));
    socket.emit('delete-task', id);
  };

  return (
    <div className="kanban-wrapper">
      <h1 className="title">Real-Time Kanban Board</h1>

      <div className="task-input">
        <input
          type="text"
          placeholder="Enter new task..."
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <button onClick={handleAddTask}>Add Task</button>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div className="kanban-board">
          {STATUSES.map((status) => (
            <Droppable droppableId={status} key={status}>
              {(provided) => (
                <div
                  className="kanban-column"
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                >
                  <h2 className="column-title">{status}</h2>
                  {tasks
                    .filter((task) => task.status === status)
                    .map((task, index) => (
                      <Draggable
                        key={task.id}
                        draggableId={task.id}
                        index={index}
                      >
                        {(provided) => (
                          <div
                            className="task-card"
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <p>{task.title}</p>
                            <button
                              className="delete-btn"
                              onClick={() => handleDeleteTask(task.id)}
                            >
                              ✖
                            </button>
                          </div>
                        )}
                      </Draggable>
                    ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          ))}
        </div>
      </DragDropContext>
    </div>
  );
};export default KanbanBoard;