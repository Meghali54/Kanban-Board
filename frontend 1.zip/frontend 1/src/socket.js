
// src/socket.js
import { io } from 'socket.io-client';

// Create and export the socket connection
export const socket = io('http://localhost:5000');

// Optional: log connection status
socket.on('connect', () => {
  console.log('✅ Connected to WebSocket server');
});

socket.on('disconnect', () => {
  console.log('🔌 Disconnected from WebSocket server');
});
